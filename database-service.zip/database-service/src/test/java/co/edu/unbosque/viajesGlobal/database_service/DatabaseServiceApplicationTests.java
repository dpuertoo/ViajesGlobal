package co.edu.unbosque.viajesGlobal.database_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
